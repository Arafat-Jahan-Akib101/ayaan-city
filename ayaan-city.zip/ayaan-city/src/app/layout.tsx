import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AYAAN City Builders Land Development Ltd. | Making Dreams With Confidence",
  description:
    "আপনার স্বপ্নের বাড়ি এখন নিরাপদ হাতে। 100% Legal Residential, Commercial & Land Development সেবা। Dhaka, Bangladesh.",
  keywords: [
    "AYAAN City",
    "real estate Bangladesh",
    "land development Dhaka",
    "residential development",
    "commercial development",
    "ayaancitybd",
  ],
  openGraph: {
    title: "AYAAN City Builders Land Development Ltd.",
    description: "Making Dreams With Confidence — Dhaka, Bangladesh",
    url: "https://www.ayaancitybd.com",
    siteName: "AYAAN City",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  );
}

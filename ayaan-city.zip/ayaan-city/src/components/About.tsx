"use client";
import { useEffect, useRef } from "react";

const milestones = [
  { year: "2009", event: "Company Founded in Dhaka" },
  { year: "2012", event: "First 100 Properties Delivered" },
  { year: "2016", event: "Expanded to Commercial Sector" },
  { year: "2020", event: "ISO Quality Certification" },
  { year: "2024", event: "500+ Projects Milestone" },
];

export default function About() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 130);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-28"
      style={{
        background: "linear-gradient(135deg, #0D1B3E 0%, #0A2010 50%, #0D1B3E 100%)",
      }}
    >
      {/* Diagonal accent line */}
      <div
        className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden"
        aria-hidden
      >
        <div
          className="absolute w-[600px] h-[600px] opacity-10"
          style={{
            top: "-100px",
            right: "-100px",
            background: "radial-gradient(circle, #C8A951 0%, transparent 70%)",
          }}
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left — timeline */}
          <div className="reveal">
            <p className="text-[#C8A951]/60 text-xs tracking-[0.3em] uppercase mb-3">Our Journey</p>
            <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-white mb-6">
              Building <span className="shimmer-text">Trust</span>
              <br />Since 2009
            </h2>
            <div className="gold-divider w-20 mb-8" />

            {/* Timeline */}
            <div className="relative pl-6 border-l border-[#C8A951]/20">
              {milestones.map((m, i) => (
                <div key={m.year} className={`reveal mb-6 last:mb-0 relative`} style={{ transitionDelay: `${i * 100}ms` }}>
                  <div className="absolute -left-[25px] w-3 h-3 rounded-full bg-[#C8A951] border-2 border-[#0D1B3E]" />
                  <div className="shimmer-text font-['Playfair_Display'] font-bold text-sm mb-0.5">{m.year}</div>
                  <div className="text-white/60 text-sm">{m.event}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right — content */}
          <div className="reveal">
            <div className="card-glass rounded-2xl p-8 mb-6">
              <h3 className="font-['Playfair_Display'] text-2xl font-bold text-[#C8A951] mb-4">
                আমাদের লক্ষ্য
              </h3>
              <p className="text-white/60 text-sm leading-relaxed mb-4">
                AYAAN City Builders Land Development Ltd. বিশ্বাস করে যে প্রতিটি মানুষের একটি নিরাপদ ও সুন্দর বাড়ির স্বপ্ন আছে। আমরা সেই স্বপ্নকে বাস্তবে রূপ দিতে প্রতিশ্রুতিবদ্ধ।
              </p>
              <p className="text-white/60 text-sm leading-relaxed">
                আমাদের সকল প্রপার্টি ১০০% লিগ্যাল, সরকার অনুমোদিত, এবং সম্পূর্ণ ডকুমেন্টেশনসহ হস্তান্তর করা হয়।
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { value: "100%", label: "Legal Properties", icon: "🛡️" },
                { value: "500+", label: "Projects Done", icon: "🏗️" },
                { value: "1200+", label: "Happy Clients", icon: "😊" },
                { value: "24/7", label: "Client Support", icon: "📞" },
              ].map((s) => (
                <div key={s.label} className="card-glass reveal rounded-xl p-5 text-center">
                  <div className="text-2xl mb-2">{s.icon}</div>
                  <div className="shimmer-text font-['Playfair_Display'] text-2xl font-bold">{s.value}</div>
                  <div className="text-white/40 text-xs mt-1">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

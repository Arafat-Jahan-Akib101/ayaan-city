export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-[#050C1A] border-t border-[#C8A951]/10">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C8A951] to-[#A88B38] flex items-center justify-center text-[#0D1B3E] font-bold text-sm">
                AC
              </div>
              <div>
                <div className="font-['Playfair_Display'] text-[#C8A951] font-bold tracking-wide">AYAAN CITY</div>
                <div className="text-white/30 text-[9px] tracking-widest uppercase">Builders Land Development Ltd.</div>
              </div>
            </div>
            <p className="text-white/40 text-sm leading-relaxed mb-4 max-w-xs">
              আপনার স্বপ্নের বাড়ি এখন নিরাপদ হাতে। ১০০% লিগ্যাল রিয়েল এস্টেট সেবা — বিশ্বস্ততার সাথে।
            </p>
            <p className="font-['Cormorant_Garamond'] italic text-[#C8A951]/60 text-sm">
              Making Dreams With Confidence
            </p>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4 tracking-wide">Services</h4>
            <ul className="space-y-2 text-white/40 text-sm">
              {["Residential Development", "Commercial Development", "Land Development", "Quality Construction", "After-Sales Service"].map((s) => (
                <li key={s} className="hover:text-[#C8A951]/70 transition-colors cursor-default">{s}</li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4 tracking-wide">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="tel:01912469308" className="text-white/40 hover:text-[#C8A951] transition-colors flex items-center gap-2">
                  <span>📞</span> 01912469308
                </a>
              </li>
              <li>
                <a href="tel:01635594194" className="text-white/40 hover:text-[#C8A951] transition-colors flex items-center gap-2">
                  <span>📞</span> 01635594194
                </a>
              </li>
              <li>
                <a href="https://www.ayaancitybd.com" className="text-white/40 hover:text-[#C8A951] transition-colors flex items-center gap-2">
                  <span>🌐</span> www.ayaancitybd.com
                </a>
              </li>
              <li>
                <span className="text-white/40 flex items-center gap-2">
                  <span>📍</span> Dhaka, Bangladesh
                </span>
              </li>
            </ul>

            <div className="flex gap-3 mt-6">
              <a
                href="https://www.facebook.com/share/1DNcoEext4/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full border border-[#C8A951]/20 flex items-center justify-center text-[#C8A951]/60 hover:text-[#C8A951] hover:border-[#C8A951]/50 transition-colors text-sm"
              >
                f
              </a>
              <a
                href="https://wa.me/8801912469308"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full border border-[#C8A951]/20 flex items-center justify-center text-[#C8A951]/60 hover:text-[#C8A951] hover:border-[#C8A951]/50 transition-colors text-xs"
              >
                WA
              </a>
            </div>
          </div>
        </div>

        <div className="gold-divider mb-6" />

        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-white/25">
          <p>© {year} AYAAN City Builders Land Development Ltd. All rights reserved.</p>
          <div className="flex gap-6">
            {["Trust", "Quality", "Commitment", "Growth"].map((v) => (
              <span key={v} className="hover:text-[#C8A951]/50 transition-colors cursor-default">{v}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

"use client";
import { useEffect, useRef } from "react";

const services = [
  {
    icon: "🏠",
    title: "Residential Development",
    bangla: "আবাসিক উন্নয়ন",
    desc: "Premium apartments, villas, and housing complexes built with modern architecture and superior quality materials for your dream home.",
    features: ["Luxury Apartments", "Duplex Villas", "Gated Communities", "Smart Home Features"],
    color: "#C8A951",
  },
  {
    icon: "🏢",
    title: "Commercial Development",
    bangla: "বাণিজ্যিক উন্নয়ন",
    desc: "State-of-the-art office spaces, shopping complexes, and mixed-use developments strategically located across Dhaka.",
    features: ["Office Spaces", "Shopping Malls", "Mixed-use Buildings", "Business Centers"],
    color: "#1B6B3A",
  },
  {
    icon: "🌿",
    title: "Land Development",
    bangla: "ভূমি উন্নয়ন",
    desc: "100% legally verified plots and land parcels in prime locations. Full documentation, transparent ownership transfer.",
    features: ["Residential Plots", "Commercial Plots", "Legal Documentation", "Clear Title Deeds"],
    color: "#C8A951",
  },
  {
    icon: "⚙️",
    title: "Quality Construction",
    bangla: "মানসম্পন্ন নির্মাণ",
    desc: "End-to-end construction services with premium grade materials, expert engineering, and strict quality control at every stage.",
    features: ["Structural Engineering", "Interior Design", "Project Management", "Post-handover Support"],
    color: "#1B6B3A",
  },
];

export default function Services() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative py-28 bg-[#080F22]"
    >
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: "radial-gradient(circle, rgba(200,169,81,1) 1px, transparent 1px)",
        backgroundSize: "40px 40px",
      }} />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* Heading */}
        <div className="text-center mb-16 reveal">
          <p className="text-[#C8A951]/60 text-xs tracking-[0.3em] uppercase mb-3">What We Offer</p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-white mb-4">
            Our <span className="shimmer-text">Services</span>
          </h2>
          <div className="gold-divider w-24 mx-auto mb-6" />
          <p className="text-white/50 max-w-xl mx-auto">
            আমরা দিচ্ছি সম্পূর্ণ রিয়েল এস্টেট সমাধান — বাড়ি থেকে বাণিজ্য, জমি থেকে নির্মাণ।
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          {services.map((s, i) => (
            <div key={s.title} className={`reveal card-glass rounded-2xl p-8 group`} style={{ transitionDelay: `${i * 100}ms` }}>
              <div className="flex items-start gap-5 mb-6">
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ background: `${s.color}15`, border: `1px solid ${s.color}30` }}
                >
                  {s.icon}
                </div>
                <div>
                  <h3 className="font-['Playfair_Display'] text-xl font-bold text-white mb-1 group-hover:text-[#C8A951] transition-colors">
                    {s.title}
                  </h3>
                  <p className="font-['Cormorant_Garamond'] italic text-[#C8A951]/60 text-sm">{s.bangla}</p>
                </div>
              </div>
              <p className="text-white/55 text-sm leading-relaxed mb-5">{s.desc}</p>
              <ul className="grid grid-cols-2 gap-2">
                {s.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-xs text-white/50">
                    <span style={{ color: s.color }}>◆</span> {f}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

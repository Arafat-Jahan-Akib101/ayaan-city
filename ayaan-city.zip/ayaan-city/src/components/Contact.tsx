"use client";
import { useState, useEffect, useRef } from "react";

export default function Contact() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [form, setForm] = useState({ name: "", phone: "", service: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = () => {
    if (!form.name || !form.phone) return;
    const msg = `Hello AYAAN City! 👋\n\nName: ${form.name}\nPhone: ${form.phone}\nService: ${form.service || "Not specified"}\nMessage: ${form.message || "Interested in your properties"}\n\nPlease contact me.`;
    const url = `https://wa.me/8801912469308?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="contact" ref={sectionRef} className="relative py-28" style={{
      background: "linear-gradient(135deg, #0A1528 0%, #0D1B3E 50%, #0A2010 100%)",
    }}>
      <div className="absolute inset-0 opacity-[0.04]" style={{
        backgroundImage: "linear-gradient(rgba(200,169,81,1) 1px, transparent 1px), linear-gradient(90deg, rgba(200,169,81,1) 1px, transparent 1px)",
        backgroundSize: "80px 80px",
      }} />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        <div className="text-center mb-16 reveal">
          <p className="text-[#C8A951]/60 text-xs tracking-[0.3em] uppercase mb-3">Get In Touch</p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-white mb-4">
            আপনার <span className="shimmer-text">স্বপ্নের</span> যাত্রা
            <br />শুরু হোক আজই
          </h2>
          <div className="gold-divider w-24 mx-auto mb-6" />
          <p className="text-white/50 max-w-xl mx-auto text-sm">
            Free consultation-এর জন্য এখনই যোগাযোগ করুন। আমাদের বিশেষজ্ঞ দল আপনাকে সঠিক সিদ্ধান্ত নিতে সাহায্য করবে।
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Form */}
          <div className="reveal card-glass rounded-2xl p-8">
            <h3 className="font-['Playfair_Display'] text-xl font-bold text-[#C8A951] mb-6">
              Free Consultation Request
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-white/50 text-xs uppercase tracking-wider mb-1.5 block">Your Name *</label>
                <input
                  type="text"
                  placeholder="আপনার নাম লিখুন"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full bg-[#0D1B3E]/60 border border-[#C8A951]/20 rounded-lg px-4 py-3 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#C8A951]/50 transition-colors"
                />
              </div>

              <div>
                <label className="text-white/50 text-xs uppercase tracking-wider mb-1.5 block">Phone Number *</label>
                <input
                  type="tel"
                  placeholder="01XXXXXXXXX"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full bg-[#0D1B3E]/60 border border-[#C8A951]/20 rounded-lg px-4 py-3 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#C8A951]/50 transition-colors"
                />
              </div>

              <div>
                <label className="text-white/50 text-xs uppercase tracking-wider mb-1.5 block">Service Interested In</label>
                <select
                  value={form.service}
                  onChange={(e) => setForm({ ...form, service: e.target.value })}
                  className="w-full bg-[#0D1B3E]/60 border border-[#C8A951]/20 rounded-lg px-4 py-3 text-white/70 text-sm focus:outline-none focus:border-[#C8A951]/50 transition-colors"
                >
                  <option value="">Select a service</option>
                  <option value="Residential">Residential Development</option>
                  <option value="Commercial">Commercial Development</option>
                  <option value="Land">Land Development</option>
                  <option value="Construction">Quality Construction</option>
                </select>
              </div>

              <div>
                <label className="text-white/50 text-xs uppercase tracking-wider mb-1.5 block">Message</label>
                <textarea
                  rows={4}
                  placeholder="আপনার বাজেট, পছন্দের এলাকা, বা যেকোনো প্রশ্ন লিখুন..."
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full bg-[#0D1B3E]/60 border border-[#C8A951]/20 rounded-lg px-4 py-3 text-white placeholder-white/30 text-sm focus:outline-none focus:border-[#C8A951]/50 transition-colors resize-none"
                />
              </div>

              <button
                onClick={handleSubmit}
                className="w-full btn-gold py-4 rounded-lg text-sm font-semibold relative z-10 flex items-center justify-center gap-2"
              >
                {submitted ? "✅ Sent! We'll contact you soon." : "📲 Send via WhatsApp"}
              </button>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            {/* Direct contact cards */}
            {[
              {
                icon: "📞",
                title: "Call Us Now",
                lines: ["01912469308", "01635594194"],
                action: "tel:01912469308",
                actionLabel: "Call Now",
                color: "#1B6B3A",
              },
              {
                icon: "💬",
                title: "WhatsApp",
                lines: ["Quick response within minutes", "Chat with our property experts"],
                action: "https://wa.me/8801912469308",
                actionLabel: "Open WhatsApp",
                color: "#22874A",
              },
              {
                icon: "🌐",
                title: "Website",
                lines: ["www.ayaancitybd.com", "Full property listings online"],
                action: "https://www.ayaancitybd.com",
                actionLabel: "Visit Website",
                color: "#C8A951",
              },
              {
                icon: "📍",
                title: "Location",
                lines: ["Dhaka, Bangladesh", "Serving all major areas in Dhaka"],
                action: "https://maps.google.com/?q=Dhaka+Bangladesh",
                actionLabel: "View on Map",
                color: "#C8A951",
              },
            ].map((c) => (
              <div key={c.title} className="reveal card-glass rounded-xl p-5 flex items-center gap-5">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                  style={{ background: `${c.color}15`, border: `1px solid ${c.color}30` }}
                >
                  {c.icon}
                </div>
                <div className="flex-1">
                  <div className="text-[#C8A951] font-semibold text-sm mb-1">{c.title}</div>
                  {c.lines.map((l) => (
                    <div key={l} className="text-white/50 text-xs">{l}</div>
                  ))}
                </div>
                <a
                  href={c.action}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-[#C8A951] border border-[#C8A951]/30 rounded px-3 py-1.5 hover:bg-[#C8A951]/10 transition-colors whitespace-nowrap"
                >
                  {c.actionLabel}
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

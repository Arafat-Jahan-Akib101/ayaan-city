"use client";
import { useEffect, useRef } from "react";

const pillars = [
  { icon: "🛡️", title: "100% Legal", desc: "Every property comes with full legal documentation, government-approved layouts and clear title deeds." },
  { icon: "🏆", title: "Premium Quality", desc: "We use Grade-A construction materials and work with certified engineers to ensure lasting quality." },
  { icon: "🤝", title: "Commitment", desc: "We deliver on every promise — on time, within budget, with zero compromise on quality." },
  { icon: "📈", title: "Growth Focus", desc: "Our properties are strategically located for maximum value appreciation and ROI." },
  { icon: "💬", title: "Transparency", desc: "Clear pricing, honest timelines, and open communication at every stage of your project." },
  { icon: "🌟", title: "After-Sales Service", desc: "Our relationship with you doesn't end at handover. We provide lifetime after-sales support." },
];

export default function WhyChooseUs() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-28 bg-[#080F22]">
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 reveal">
          <p className="text-[#C8A951]/60 text-xs tracking-[0.3em] uppercase mb-3">Why Us</p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-white mb-4">
            কেন <span className="shimmer-text">AYAAN City</span> বেছে নেবেন?
          </h2>
          <div className="gold-divider w-24 mx-auto mb-6" />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pillars.map((p, i) => (
            <div
              key={p.title}
              className="reveal card-glass rounded-2xl p-6 group cursor-default"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-12 h-12 rounded-xl bg-[#C8A951]/10 border border-[#C8A951]/20 flex items-center justify-center text-xl mb-4 group-hover:bg-[#C8A951]/20 transition-colors">
                {p.icon}
              </div>
              <h3 className="font-['Playfair_Display'] font-bold text-white text-lg mb-2 group-hover:text-[#C8A951] transition-colors">
                {p.title}
              </h3>
              <p className="text-white/50 text-sm leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

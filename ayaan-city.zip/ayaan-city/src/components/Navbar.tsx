"use client";
import { useState, useEffect } from "react";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Projects", href: "#projects" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[#080F22]/95 backdrop-blur-md shadow-[0_4px_30px_rgba(0,0,0,0.5)]"
          : "bg-transparent"
      }`}
    >
      {/* Top bar */}
      <div className="border-b border-[#C8A951]/20 hidden md:block">
        <div className="max-w-7xl mx-auto px-6 py-2 flex justify-between items-center text-xs text-[#C8A951]/70">
          <span>🏠 100% Legal Residential, Commercial & Land Development</span>
          <div className="flex gap-6">
            <a href="tel:01912469308" className="hover:text-[#C8A951] transition-colors">📞 01912469308</a>
            <a href="https://www.ayaancitybd.com" className="hover:text-[#C8A951] transition-colors">🌐 www.ayaancitybd.com</a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C8A951] to-[#A88B38] flex items-center justify-center text-[#0D1B3E] font-bold text-sm">
            AC
          </div>
          <div>
            <div className="font-['Playfair_Display'] text-[#C8A951] font-bold text-sm leading-tight tracking-wide">
              AYAAN CITY
            </div>
            <div className="text-white/50 text-[9px] tracking-widest uppercase">
              Builders Land Development
            </div>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-white/70 hover:text-[#C8A951] text-sm font-medium tracking-wide transition-colors relative group"
            >
              {link.label}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-[#C8A951] transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>

        {/* CTA */}
        <a
          href="#contact"
          className="hidden md:block btn-gold px-5 py-2.5 rounded text-sm font-semibold relative z-10"
        >
          Get a Free Consultation
        </a>

        {/* Hamburger */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <div className={`w-6 h-0.5 bg-[#C8A951] mb-1.5 transition-all ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
          <div className={`w-6 h-0.5 bg-[#C8A951] mb-1.5 transition-all ${menuOpen ? "opacity-0" : ""}`} />
          <div className={`w-6 h-0.5 bg-[#C8A951] transition-all ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-[#080F22]/98 border-t border-[#C8A951]/20 px-6 pb-6 pt-2">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="block py-3 text-white/80 hover:text-[#C8A951] border-b border-white/5 transition-colors text-sm"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setMenuOpen(false)}
            className="btn-gold block text-center mt-4 py-3 rounded text-sm font-semibold relative z-10"
          >
            Free Consultation
          </a>
        </div>
      )}
    </header>
  );
}

"use client";
import { useEffect, useState } from "react";

const stats = [
  { value: "500+", label: "Projects Delivered" },
  { value: "15+", label: "Years of Trust" },
  { value: "100%", label: "Legal Properties" },
  { value: "1200+", label: "Happy Families" },
];

export default function Hero() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      id="home"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
      style={{
        background:
          "radial-gradient(ellipse at 70% 50%, rgba(27,107,58,0.15) 0%, transparent 60%), radial-gradient(ellipse at 30% 80%, rgba(200,169,81,0.1) 0%, transparent 50%), linear-gradient(135deg, #080F22 0%, #0D1B3E 50%, #0A1528 100%)",
      }}
    >
      {/* Decorative grid */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(200,169,81,1) 1px, transparent 1px), linear-gradient(90deg, rgba(200,169,81,1) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Floating orbs */}
      <div className="absolute top-1/4 right-1/4 w-80 h-80 bg-[#1B6B3A]/10 rounded-full blur-[100px] animate-pulse" />
      <div className="absolute bottom-1/3 left-1/5 w-60 h-60 bg-[#C8A951]/8 rounded-full blur-[80px] animate-pulse delay-1000" />

      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left — Text */}
          <div>
            {/* Badge */}
            <div
              className={`inline-flex items-center gap-2 border border-[#C8A951]/30 rounded-full px-4 py-1.5 mb-8 text-xs tracking-widest text-[#C8A951]/80 uppercase transition-all duration-700 ${
                visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              <span className="w-1.5 h-1.5 bg-[#C8A951] rounded-full animate-pulse" />
              Making Dreams With Confidence
            </div>

            <h1
              className={`font-['Playfair_Display'] text-5xl md:text-6xl xl:text-7xl font-bold leading-[1.1] mb-6 transition-all duration-700 delay-100 ${
                visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <span className="text-white">Building</span>{" "}
              <span className="shimmer-text">Today</span>
              <br />
              <span className="text-white">For a Better</span>
              <br />
              <span className="text-[#1B6B3A]">Tomorrow</span>
            </h1>

            <p
              className={`font-['Cormorant_Garamond'] italic text-xl text-[#C8A951]/80 mb-4 transition-all duration-700 delay-150 ${
                visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              বিশ্বস্ততার সাথে গড়ি, আপনার স্বপ্নের ভবিষ্যৎ
            </p>

            <p
              className={`text-white/60 text-base leading-relaxed max-w-lg mb-10 transition-all duration-700 delay-200 ${
                visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              আপনার স্বপ্নের বাড়ি এখন নিরাপদ হাতে। আমরা দিচ্ছি ১০০% লিগ্যাল
              Residential, Commercial ও Land Development সেবা — আধুনিক ডিজাইন ও
              বিশ্বস্ততার সাথে।
            </p>

            <div
              className={`flex flex-wrap gap-4 transition-all duration-700 delay-300 ${
                visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <a href="#contact" className="btn-gold px-8 py-4 rounded text-sm font-semibold relative z-10">
                📞 Free Consultation
              </a>
              <a href="#projects" className="btn-outline px-8 py-4 rounded text-sm font-semibold">
                View Projects →
              </a>
            </div>

            {/* Trust badges */}
            <div
              className={`flex gap-6 mt-10 transition-all duration-700 delay-400 ${
                visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              {["🛡️ Trust", "🏆 Quality", "🤝 Commitment", "📈 Growth"].map((b) => (
                <div key={b} className="text-xs text-white/40 hover:text-[#C8A951]/70 transition-colors">
                  {b}
                </div>
              ))}
            </div>
          </div>

          {/* Right — Visual card */}
          <div
            className={`relative transition-all duration-900 delay-200 ${
              visible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
            }`}
          >
            {/* Main card */}
            <div className="relative card-glass rounded-2xl p-8 border-[#C8A951]/20">
              {/* Mock building illustration */}
              <div className="aspect-[4/3] rounded-xl overflow-hidden bg-gradient-to-br from-[#0D1B3E] to-[#162650] flex items-center justify-center mb-6 relative">
                <div className="absolute inset-0 bg-gradient-to-t from-[#080F22]/80 to-transparent z-10" />
                {/* Skyline SVG */}
                <svg viewBox="0 0 400 300" className="w-full h-full" fill="none">
                  {/* Sky gradient */}
                  <defs>
                    <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#162650" />
                      <stop offset="100%" stopColor="#0D1B3E" />
                    </linearGradient>
                    <linearGradient id="goldBld" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#E0C06A" />
                      <stop offset="100%" stopColor="#A88B38" />
                    </linearGradient>
                  </defs>
                  <rect width="400" height="300" fill="url(#sky)" />
                  {/* Stars */}
                  {[30,60,90,130,170,200,250,300,340,380].map((x,i) => (
                    <circle key={i} cx={x} cy={20+i*3} r="1" fill="#C8A951" opacity="0.6" />
                  ))}
                  {/* Buildings */}
                  <rect x="20" y="120" width="50" height="180" fill="#1a2d5a" />
                  <rect x="25" y="130" width="8" height="10" fill="#C8A951" opacity="0.7" />
                  <rect x="38" y="130" width="8" height="10" fill="#C8A951" opacity="0.5" />
                  <rect x="51" y="130" width="8" height="10" fill="#C8A951" opacity="0.8" />
                  <rect x="25" y="150" width="8" height="10" fill="#C8A951" opacity="0.4" />
                  <rect x="38" y="150" width="8" height="10" fill="#C8A951" opacity="0.9" />

                  {/* Main tall building - gold */}
                  <rect x="140" y="60" width="70" height="240" fill="url(#goldBld)" opacity="0.9" />
                  <rect x="148" y="75" width="12" height="16" fill="#0D1B3E" opacity="0.7" />
                  <rect x="165" y="75" width="12" height="16" fill="#0D1B3E" opacity="0.7" />
                  <rect x="182" y="75" width="12" height="16" fill="#0D1B3E" opacity="0.7" />
                  <rect x="148" y="100" width="12" height="16" fill="#0D1B3E" opacity="0.5" />
                  <rect x="165" y="100" width="12" height="16" fill="#0D1B3E" opacity="0.9" />
                  <rect x="182" y="100" width="12" height="16" fill="#0D1B3E" opacity="0.7" />
                  <rect x="148" y="125" width="12" height="16" fill="#0D1B3E" opacity="0.8" />
                  <rect x="165" y="125" width="12" height="16" fill="#0D1B3E" opacity="0.4" />
                  <rect x="182" y="125" width="12" height="16" fill="#0D1B3E" opacity="0.6" />
                  {/* Spire */}
                  <polygon points="175,20 168,60 182,60" fill="#C8A951" />

                  {/* Right building - emerald */}
                  <rect x="240" y="90" width="80" height="210" fill="#1B6B3A" opacity="0.8" />
                  <rect x="248" y="105" width="14" height="18" fill="#22874A" opacity="0.7" />
                  <rect x="268" y="105" width="14" height="18" fill="#22874A" opacity="0.5" />
                  <rect x="288" y="105" width="14" height="18" fill="#22874A" opacity="0.9" />
                  <rect x="248" y="133" width="14" height="18" fill="#22874A" opacity="0.6" />
                  <rect x="268" y="133" width="14" height="18" fill="#22874A" opacity="0.8" />
                  <rect x="288" y="133" width="14" height="18" fill="#22874A" opacity="0.4" />

                  {/* Far right small building */}
                  <rect x="340" y="140" width="45" height="160" fill="#162650" />
                  <rect x="347" y="155" width="8" height="10" fill="#C8A951" opacity="0.6" />
                  <rect x="360" y="155" width="8" height="10" fill="#C8A951" opacity="0.8" />
                  <rect x="347" y="173" width="8" height="10" fill="#C8A951" opacity="0.4" />
                  <rect x="360" y="173" width="8" height="10" fill="#C8A951" opacity="0.7" />

                  {/* Ground */}
                  <rect x="0" y="270" width="400" height="30" fill="#080F22" />
                  {/* Ground glow */}
                  <ellipse cx="200" cy="270" rx="200" ry="8" fill="#C8A951" opacity="0.1" />
                  {/* Trees */}
                  <ellipse cx="110" cy="255" rx="18" ry="22" fill="#1B6B3A" opacity="0.8" />
                  <rect x="107" y="268" width="6" height="15" fill="#145029" />
                </svg>
                <div className="absolute bottom-4 left-4 z-20 text-white/90 font-['Playfair_Display'] font-bold text-lg">
                  Dhaka, Bangladesh
                </div>
              </div>

              {/* Services strip */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: "🏠", label: "Residential", sub: "Development" },
                  { icon: "🏢", label: "Commercial", sub: "Development" },
                  { icon: "🌿", label: "Land", sub: "Development" },
                  { icon: "⚙️", label: "Quality", sub: "Construction" },
                ].map((s) => (
                  <div key={s.label} className="bg-[#0D1B3E]/60 border border-[#C8A951]/10 rounded-lg p-3 flex items-center gap-3 hover:border-[#C8A951]/30 transition-colors">
                    <span className="text-xl">{s.icon}</span>
                    <div>
                      <div className="text-[#C8A951] text-xs font-semibold">{s.label}</div>
                      <div className="text-white/40 text-[10px]">{s.sub}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -top-4 -right-4 bg-gradient-to-br from-[#C8A951] to-[#A88B38] rounded-2xl p-4 text-[#0D1B3E] text-center shadow-2xl animate-[float_3s_ease-in-out_infinite]">
              <div className="text-2xl font-bold font-['Playfair_Display']">15+</div>
              <div className="text-xs font-semibold leading-tight">Years of<br />Excellence</div>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div
          className={`grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 transition-all duration-700 delay-500 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          {stats.map((s) => (
            <div key={s.label} className="card-glass rounded-xl p-5 text-center">
              <div className="shimmer-text font-['Playfair_Display'] text-3xl font-bold mb-1">
                {s.value}
              </div>
              <div className="text-white/50 text-xs tracking-wide">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-[#080F22] to-transparent" />
    </section>
  );
}

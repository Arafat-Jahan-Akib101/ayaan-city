"use client";
import { useEffect, useRef, useState } from "react";

const projects = [
  {
    title: "Ayaan Residency",
    type: "Residential",
    location: "Mirpur, Dhaka",
    units: "48 Units",
    status: "Completed",
    color: "#C8A951",
    floors: "12 Floors",
  },
  {
    title: "City Commerce Hub",
    type: "Commercial",
    location: "Gulshan, Dhaka",
    units: "30 Offices",
    status: "Ongoing",
    color: "#1B6B3A",
    floors: "8 Floors",
  },
  {
    title: "Green Valley Plot",
    type: "Land",
    location: "Purbachal, Dhaka",
    units: "120 Plots",
    status: "Available",
    color: "#C8A951",
    floors: "Residential Zone",
  },
  {
    title: "Ayaan Heights",
    type: "Residential",
    location: "Bashundhara, Dhaka",
    units: "72 Units",
    status: "Upcoming",
    color: "#1B6B3A",
    floors: "18 Floors",
  },
  {
    title: "Business Square",
    type: "Commercial",
    location: "Banani, Dhaka",
    units: "50 Spaces",
    status: "Ongoing",
    color: "#C8A951",
    floors: "10 Floors",
  },
  {
    title: "Dream Garden",
    type: "Land",
    location: "Uttara, Dhaka",
    units: "80 Plots",
    status: "Completed",
    color: "#1B6B3A",
    floors: "Premium Zone",
  },
];

const statusColors: Record<string, string> = {
  Completed: "#22874A",
  Ongoing: "#C8A951",
  Available: "#1B6B3A",
  Upcoming: "#4A90D9",
};

export default function Projects() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const filtered = filter === "All" ? projects : projects.filter((p) => p.type === filter);

  return (
    <section id="projects" ref={sectionRef} className="relative py-28" style={{
      background: "linear-gradient(180deg, #0D1B3E 0%, #080F22 100%)",
    }}>
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-12 reveal">
          <p className="text-[#C8A951]/60 text-xs tracking-[0.3em] uppercase mb-3">Portfolio</p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-white mb-4">
            Featured <span className="shimmer-text">Projects</span>
          </h2>
          <div className="gold-divider w-24 mx-auto mb-6" />
          <p className="text-white/50 text-sm max-w-lg mx-auto">
            আমাদের সেরা প্রকল্পগুলো — প্রতিটি স্বপ্নকে বাস্তবে রূপ দেওয়ার প্রমাণ।
          </p>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-3 justify-center mb-10 reveal flex-wrap">
          {["All", "Residential", "Commercial", "Land"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
                filter === f
                  ? "bg-[#C8A951] text-[#0D1B3E]"
                  : "border border-[#C8A951]/30 text-white/60 hover:border-[#C8A951]/60 hover:text-white/80"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((p, i) => (
            <div
              key={p.title}
              className="reveal card-glass rounded-2xl overflow-hidden group"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              {/* Mock image header */}
              <div
                className="h-44 flex items-end p-4 relative overflow-hidden"
                style={{
                  background: `linear-gradient(135deg, ${p.color}20 0%, #080F22 100%)`,
                  borderBottom: `1px solid ${p.color}20`,
                }}
              >
                <div
                  className="absolute inset-0 opacity-5"
                  style={{
                    backgroundImage: "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)",
                    backgroundSize: "20px 20px",
                  }}
                />
                {/* Building silhouette */}
                <div className="absolute bottom-0 right-4 opacity-20" style={{ color: p.color }}>
                  <svg width="80" height="100" viewBox="0 0 80 100" fill="currentColor">
                    <rect x="20" y="20" width="40" height="80" />
                    <rect x="25" y="30" width="10" height="12" fill="rgba(255,255,255,0.5)" />
                    <rect x="40" y="30" width="10" height="12" fill="rgba(255,255,255,0.5)" />
                    <rect x="25" y="50" width="10" height="12" fill="rgba(255,255,255,0.5)" />
                    <rect x="40" y="50" width="10" height="12" fill="rgba(255,255,255,0.5)" />
                    <rect x="32" y="0" width="16" height="22" />
                  </svg>
                </div>

                <div className="relative z-10">
                  <span
                    className="inline-block px-3 py-1 rounded-full text-[10px] font-semibold text-white mb-2"
                    style={{ background: statusColors[p.status] }}
                  >
                    {p.status}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-['Playfair_Display'] text-lg font-bold text-white group-hover:text-[#C8A951] transition-colors">
                    {p.title}
                  </h3>
                  <span className="text-[10px] border rounded-full px-2 py-0.5" style={{ borderColor: `${p.color}40`, color: p.color }}>
                    {p.type}
                  </span>
                </div>
                <p className="text-white/40 text-xs mb-4">📍 {p.location}</p>
                <div className="flex gap-4 text-xs text-white/50">
                  <span>🏗️ {p.floors}</span>
                  <span>🏠 {p.units}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-10 reveal">
          <a href="#contact" className="btn-outline px-8 py-3 rounded text-sm inline-block">
            Inquire About a Project →
          </a>
        </div>
      </div>
    </section>
  );
}

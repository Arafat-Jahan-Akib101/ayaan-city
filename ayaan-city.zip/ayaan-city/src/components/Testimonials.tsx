"use client";
import { useEffect, useRef } from "react";

const testimonials = [
  {
    name: "রাহেলা বেগম",
    role: "Homeowner, Mirpur",
    text: "AYAAN City-র সাথে আমার অভিজ্ঞতা অসাধারণ। সমস্ত কাগজপত্র সম্পূর্ণ সঠিক ছিল এবং সময়মতো ফ্ল্যাট হস্তান্তর পেয়েছি। সত্যিকারের বিশ্বস্ত প্রতিষ্ঠান।",
    rating: 5,
    avatar: "R",
  },
  {
    name: "Mohammad Karim",
    role: "Business Owner, Gulshan",
    text: "Purchased a commercial space from AYAAN City for our office. The legal documentation was spotless and the construction quality exceeded our expectations. Highly recommended!",
    rating: 5,
    avatar: "K",
  },
  {
    name: "Sadia Islam",
    role: "Plot Owner, Purbachal",
    text: "আমি AYAAN City থেকে একটি প্লট কিনেছি। পুরো প্রক্রিয়া স্বচ্ছ ছিল এবং তাদের পরবর্তী সেবাও চমৎকার। ভবিষ্যতে আরও বিনিয়োগ করবো।",
    rating: 5,
    avatar: "S",
  },
  {
    name: "Arif Hossain",
    role: "Investor, Bashundhara",
    text: "After dealing with multiple real estate companies, AYAAN City stands out for their commitment to quality and legal compliance. My family is proud homeowners now.",
    rating: 5,
    avatar: "A",
  },
];

export default function Testimonials() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="testimonials" ref={sectionRef} className="relative py-28 bg-[#080F22]">
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 reveal">
          <p className="text-[#C8A951]/60 text-xs tracking-[0.3em] uppercase mb-3">Client Stories</p>
          <h2 className="font-['Playfair_Display'] text-4xl md:text-5xl font-bold text-white mb-4">
            What Our <span className="shimmer-text">Clients Say</span>
          </h2>
          <div className="gold-divider w-24 mx-auto" />
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className="reveal card-glass rounded-2xl p-7 group"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <span key={j} className="text-[#C8A951] text-sm">★</span>
                ))}
              </div>

              {/* Quote mark */}
              <div className="font-['Playfair_Display'] text-6xl text-[#C8A951]/20 leading-none mb-2 -mt-2">"</div>

              <p className="text-white/65 text-sm leading-relaxed mb-6 font-['Cormorant_Garamond'] text-base italic">
                {t.text}
              </p>

              <div className="flex items-center gap-4 border-t border-[#C8A951]/10 pt-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#C8A951] to-[#A88B38] flex items-center justify-center text-[#0D1B3E] font-bold text-sm">
                  {t.avatar}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{t.name}</div>
                  <div className="text-white/40 text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
